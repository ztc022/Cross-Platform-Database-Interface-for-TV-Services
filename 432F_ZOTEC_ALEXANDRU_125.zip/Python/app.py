from flask import Flask, render_template, request, redirect, flash, url_for
import pymysql

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Replace with a secure key

# Database connection function
def create_connection():
    try:
        connection = pymysql.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            database='TV'
        )
        return connection
    except pymysql.Error as e:
        print(f"Error: {e}")
        return None

# Route: Homepage
@app.route('/')
def index():
    return render_template('index.html')

# Route: Manage Clients
@app.route('/clients', methods=['GET', 'POST'])
def manage_clients():
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                name = request.form.get('name')
                preferences = request.form.get('preferences')
                if name and preferences:
                    cursor.execute(
                        "INSERT INTO Clients (nume, prefernces) VALUES (%s, %s)",
                        (name, preferences)
                    )
                    connection.commit()
                    flash("Client added successfully!", "success")
                else:
                    flash("Please fill out all fields!", "danger")
            elif action == 'modify':
                client_id = request.form.get('client_id')
                name = request.form.get('name')
                preferences = request.form.get('preferences')
                if client_id and name and preferences:
                    cursor.execute(
                        "UPDATE Clients SET nume = %s, prefernces = %s WHERE id = %s",
                        (name, preferences, client_id)
                    )
                    connection.commit()
                    flash("Client modified successfully!", "success")
                else:
                    flash("Please fill out all fields for modification!", "danger")
            elif action == 'delete':
                client_id = request.form.get('client_id')
                if client_id:
                    cursor.execute("DELETE FROM Clients WHERE id = %s", (client_id,))
                    connection.commit()
                    flash("Client deleted successfully!", "success")
                else:
                    flash("Please provide a valid client ID for deletion.", "danger")

        cursor.execute("SELECT * FROM Clients")
        clients_data = cursor.fetchall()
        connection.close()
        return render_template('clients.html', clients=clients_data)

# Route: Manage TV Channels
@app.route('/tv_channels', methods=['GET', 'POST'])
def manage_tv_channels():
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        if request.method == 'POST':
            action = request.form.get('action')
            if action == 'add':
                title = request.form.get('title')
                channel_no = request.form.get('channel_no')
                if title and channel_no:
                    cursor.execute(
                        "INSERT INTO TVChannels (titlu, channel_no) VALUES (%s, %s)",
                        (title, channel_no)
                    )
                    connection.commit()
                    flash("TV Channel added successfully!", "success")
                else:
                    flash("Please fill out all fields!", "danger")
            elif action == 'modify':
                channel_id = request.form.get('channel_id')
                title = request.form.get('title')
                channel_no = request.form.get('channel_no')
                if channel_id and title and channel_no:
                    cursor.execute(
                        "UPDATE TVChannels SET titlu = %s, channel_no = %s WHERE id = %s",
                        (title, channel_no, channel_id)
                    )
                    connection.commit()
                    flash("TV Channel modified successfully!", "success")
                else:
                    flash("Please fill out all fields for modification!", "danger")
            elif action == 'delete':
                channel_id = request.form.get('channel_id')
                if channel_id:
                    cursor.execute("DELETE FROM TVChannels WHERE id = %s", (channel_id,))
                    connection.commit()
                    flash("TV Channel deleted successfully!", "success")
                else:
                    flash("Please provide a valid channel ID for deletion.", "danger")

        cursor.execute("SELECT * FROM TVChannels")
        channels_data = cursor.fetchall()
        connection.close()
        return render_template('tv_channels.html', channels=channels_data)


# Route: Manage TV Clients
@app.route('/tv_clients', methods=['GET'])
def manage_tv_clients():
    connection = create_connection()
    if connection:
        cursor = connection.cursor()
        cursor.execute(
            "SELECT TVChannels.titlu, Clients.nume FROM TV_Clients "
            "JOIN TVChannels ON TV_Clients.id_TVChannels = TVChannels.id "
            "JOIN Clients ON TV_Clients.id_Clients = Clients.id"
        )
        tv_clients_data = cursor.fetchall()
        connection.close()
        return render_template('tv_clients.html', tv_clients=tv_clients_data)

# Start the app
if __name__ == '__main__':
    app.run(debug=True)
