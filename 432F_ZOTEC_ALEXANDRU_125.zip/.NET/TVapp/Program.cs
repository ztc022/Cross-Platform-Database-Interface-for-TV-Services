using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TVManagementWinFormsApp
{
    public class MainForm : Form
    {
        // UI Components
        private ListBox listBoxClients;
        private ListBox listBoxChannels;
        private ListBox listBoxRelationships;
        private TextBox txtClientName, txtPreferences, txtChannelTitle, txtChannelNumber;
        private Button btnAddClient, btnModifyClient, btnDeleteClient;
        private Button btnAddChannel, btnModifyChannel, btnDeleteChannel;
        private Button btnCreateRelationship, btnDeleteRelationship;

        // Database connection string
        private string connectionString = "Server=127.0.0.1;Database=TV;User ID=root;Password=root;";

        public MainForm()
        {
            Text = "TV Management";
            Width = 1000;
            Height = 600;

            // Test the database connection
            TestDatabaseConnection();

            // Initialize UI and load data
            InitializeUI();
            DisplayClients();
            DisplayChannels();
            DisplayRelationships();
        }

        private void TestDatabaseConnection()
        {
            try
            {
                using (var conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    MessageBox.Show("Database connection successful!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed: {ex.Message}");
                Environment.Exit(1); // Exit the application if the connection fails
            }
        }

        private void InitializeUI()
        {
            // ListBoxes
            listBoxClients = new ListBox { Top = 20, Left = 20, Width = 250, Height = 200 };
            listBoxChannels = new ListBox { Top = 20, Left = 290, Width = 250, Height = 200 };
            listBoxRelationships = new ListBox { Top = 20, Left = 560, Width = 250, Height = 200 };

            // TextBoxes
            txtClientName = new TextBox { Top = 240, Left = 20, Width = 150, PlaceholderText = "Client Name" };
            txtPreferences = new TextBox { Top = 270, Left = 20, Width = 150, PlaceholderText = "Preferences" };
            txtChannelTitle = new TextBox { Top = 240, Left = 290, Width = 150, PlaceholderText = "Channel Title" };
            txtChannelNumber = new TextBox { Top = 270, Left = 290, Width = 150, PlaceholderText = "Channel Number" };

            // Buttons for Clients
            btnAddClient = new Button { Top = 310, Left = 20, Width = 150, Text = "Add Client" };
            btnModifyClient = new Button { Top = 350, Left = 20, Width = 150, Text = "Modify Client" };
            btnDeleteClient = new Button { Top = 390, Left = 20, Width = 150, Text = "Delete Client" };

            // Buttons for Channels
            btnAddChannel = new Button { Top = 310, Left = 290, Width = 150, Text = "Add Channel" };
            btnModifyChannel = new Button { Top = 350, Left = 290, Width = 150, Text = "Modify Channel" };
            btnDeleteChannel = new Button { Top = 390, Left = 290, Width = 150, Text = "Delete Channel" };

            // Buttons for Relationships
            btnCreateRelationship = new Button { Top = 310, Left = 560, Width = 150, Text = "Create Relationship" };
            btnDeleteRelationship = new Button { Top = 350, Left = 560, Width = 150, Text = "Delete Relationship" };

            // Add controls to the form
            Controls.AddRange(new Control[] {
                listBoxClients, listBoxChannels, listBoxRelationships,
                txtClientName, txtPreferences, txtChannelTitle, txtChannelNumber,
                btnAddClient, btnModifyClient, btnDeleteClient,
                btnAddChannel, btnModifyChannel, btnDeleteChannel,
                btnCreateRelationship, btnDeleteRelationship
            });

            // Attach event handlers
            btnAddClient.Click += BtnAddClient_Click;
            btnModifyClient.Click += BtnModifyClient_Click;
            btnDeleteClient.Click += BtnDeleteClient_Click;
            btnAddChannel.Click += BtnAddChannel_Click;
            btnModifyChannel.Click += BtnModifyChannel_Click;
            btnDeleteChannel.Click += BtnDeleteChannel_Click;
            btnCreateRelationship.Click += BtnCreateRelationship_Click;
            btnDeleteRelationship.Click += BtnDeleteRelationship_Click;
        }

        // ---------- Clients CRUD ----------
        private void BtnAddClient_Click(object sender, EventArgs e)
        {
            string name = txtClientName.Text;
            string preferences = txtPreferences.Text;

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(preferences))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "INSERT INTO Clients (nume, prefernces) VALUES (@name, @preferences)";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@preferences", preferences);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayClients();
        }

        private void BtnModifyClient_Click(object sender, EventArgs e)
        {
            if (listBoxClients.SelectedItem == null)
            {
                MessageBox.Show("Select a client!");
                return;
            }

            var parts = listBoxClients.SelectedItem.ToString().Split('|');
            string clientId = parts[0].Trim();
            string newName = txtClientName.Text;
            string newPreferences = txtPreferences.Text;

            if (string.IsNullOrWhiteSpace(newName) || string.IsNullOrWhiteSpace(newPreferences))
            {
                MessageBox.Show("Fill all fields!");
                return;
            }

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "UPDATE Clients SET nume=@name, prefernces=@preferences WHERE id=@id";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@name", newName);
                    cmd.Parameters.AddWithValue("@preferences", newPreferences);
                    cmd.Parameters.AddWithValue("@id", clientId);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayClients();
        }

        private void BtnDeleteClient_Click(object sender, EventArgs e)
        {
            if (listBoxClients.SelectedItem == null)
            {
                MessageBox.Show("Select a client!");
                return;
            }

            var parts = listBoxClients.SelectedItem.ToString().Split('|');
            string clientId = parts[0].Trim();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "DELETE FROM Clients WHERE id=@id";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", clientId);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayClients();
            DisplayRelationships();
        }

        // ---------- TV Channels CRUD ----------
        private void BtnAddChannel_Click(object sender, EventArgs e)
        {
            string title = txtChannelTitle.Text;
            if (!int.TryParse(txtChannelNumber.Text, out int channelNumber))
            {
                MessageBox.Show("Channel number must be a valid number!");
                return;
            }

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "INSERT INTO TVChannels (titlu, channel_no) VALUES (@title, @channelNumber)";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@channelNumber", channelNumber);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayChannels();
        }

        private void BtnModifyChannel_Click(object sender, EventArgs e)
        {
            if (listBoxChannels.SelectedItem == null)
            {
                MessageBox.Show("Select a channel!");
                return;
            }

            var parts = listBoxChannels.SelectedItem.ToString().Split('|');
            string channelId = parts[0].Trim();
            string newTitle = txtChannelTitle.Text;
            if (!int.TryParse(txtChannelNumber.Text, out int newChannelNumber))
            {
                MessageBox.Show("Channel number must be a valid number!");
                return;
            }

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "UPDATE TVChannels SET titlu=@title, channel_no=@channelNumber WHERE id=@id";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@title", newTitle);
                    cmd.Parameters.AddWithValue("@channelNumber", newChannelNumber);
                    cmd.Parameters.AddWithValue("@id", channelId);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayChannels();
        }

        private void BtnDeleteChannel_Click(object sender, EventArgs e)
        {
            if (listBoxChannels.SelectedItem == null)
            {
                MessageBox.Show("Select a channel!");
                return;
            }

            var parts = listBoxChannels.SelectedItem.ToString().Split('|');
            string channelId = parts[0].Trim();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "DELETE FROM TVChannels WHERE id=@id";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@id", channelId);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayChannels();
            DisplayRelationships();
        }

        // ---------- Relationships ----------
        private void BtnCreateRelationship_Click(object sender, EventArgs e)
        {
            if (listBoxClients.SelectedItem == null || listBoxChannels.SelectedItem == null)
            {
                MessageBox.Show("Select a client and a channel!");
                return;
            }

            var partsClient = listBoxClients.SelectedItem.ToString().Split('|');
            string clientId = partsClient[0].Trim();
            var partsChannel = listBoxChannels.SelectedItem.ToString().Split('|');
            string channelId = partsChannel[0].Trim();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "INSERT INTO TV_Clients (id_TVChannels, id_Clients) VALUES (@channelId, @clientId)";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@channelId", channelId);
                    cmd.Parameters.AddWithValue("@clientId", clientId);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayRelationships();
        }

        private void BtnDeleteRelationship_Click(object sender, EventArgs e)
        {
            if (listBoxRelationships.SelectedItem == null)
            {
                MessageBox.Show("Select a relationship!");
                return;
            }

            var parts = listBoxRelationships.SelectedItem.ToString().Split('|');
            string clientName = parts[0].Trim();
            string channelTitle = parts[1].Trim();

            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"
                    DELETE TC
                    FROM TV_Clients TC
                    JOIN Clients C ON TC.id_Clients = C.id
                    JOIN TVChannels T ON TC.id_TVChannels = T.id
                    WHERE C.nume = @clientName AND T.titlu = @channelTitle";
                using (var cmd = new MySqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@clientName", clientName);
                    cmd.Parameters.AddWithValue("@channelTitle", channelTitle);
                    cmd.ExecuteNonQuery();
                }
            }

            DisplayRelationships();
        }

        // ---------- Display Methods ----------
        private void DisplayClients()
        {
            listBoxClients.Items.Clear();
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Clients";
                using (var cmd = new MySqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32("id");
                        string name = reader.GetString("nume");
                        string preferences = reader.GetString("prefernces");
                        listBoxClients.Items.Add($"{id} | {name} | {preferences}");
                    }
                }
            }
        }

        private void DisplayChannels()
        {
            listBoxChannels.Items.Clear();
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM TVChannels";
                using (var cmd = new MySqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        int id = reader.GetInt32("id");
                        string title = reader.GetString("titlu");
                        int channelNumber = reader.GetInt32("channel_no");
                        listBoxChannels.Items.Add($"{id} | {title} | {channelNumber}");
                    }
                }
            }
        }

        private void DisplayRelationships()
        {
            listBoxRelationships.Items.Clear();
            using (var conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string sql = @"
                    SELECT C.nume, T.titlu
                    FROM TV_Clients TC
                    JOIN Clients C ON TC.id_Clients = C.id
                    JOIN TVChannels T ON TC.id_TVChannels = T.id";
                using (var cmd = new MySqlCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string clientName = reader.GetString("nume");
                        string channelTitle = reader.GetString("titlu");
                        listBoxRelationships.Items.Add($"{clientName} | {channelTitle}");
                    }
                }
            }
        }

        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
